# Partnership HUMMAN UPNVYK

Website partnership directory untuk HUMMAN (Himpunan Mahasiswa Program Studi
Manajemen) UPN "Veteran" Yogyakarta. Dibangun dengan **React + Vite +
Tailwind CSS**.

## Struktur folder

```
src/
  components/       -> Navbar, HeroSection, AboutSection, PartnerGrid,
                        PartnerCard, PartnerDetail, Footer, ImagePlaceholder
  data/
    partners.js     -> SEMUA data partner ada di sini. Ini satu-satunya
                        file yang perlu diedit saat data partner asli
                        (logo, foto, nama, kategori, dll) sudah tersedia.
  App.jsx           -> merangkai semua komponen + navigasi antar "halaman"
  main.jsx          -> entry point React
  index.css         -> Tailwind + animasi custom
```

## Menjalankan di komputer sendiri (opsional, untuk lihat sebelum deploy)

Butuh Node.js versi 18 ke atas.

```bash
npm install
npm run dev
```

Buka `http://localhost:5173` di browser.

## Deploy jadi link online (paling gampang: Vercel)

1. **Upload project ini ke GitHub**
   - Buat repository baru di [github.com](https://github.com) (bisa
     private atau public).
   - Upload seluruh folder project ini (bisa drag & drop lewat web GitHub,
     atau pakai `git push` kalau familiar dengan git).

2. **Hubungkan ke Vercel**
   - Buka [vercel.com](https://vercel.com), daftar/login pakai akun GitHub.
   - Klik **"Add New Project"**, pilih repository yang tadi di-upload.
   - Vercel otomatis mendeteksi ini project Vite — biarkan pengaturan
     default, klik **Deploy**.
   - Setelah selesai (sekitar 1 menit), Vercel akan kasih link seperti
     `https://partnership-humman.vercel.app`.

Alternatif lain yang sama mudahnya: [Netlify](https://netlify.com) — caranya
mirip, tinggal connect ke GitHub repo yang sama.

## Mengganti data partner

Buka `src/data/partners.js`, ganti nilai tiap field pada array `PARTNERS`
(nama, kategori, logo, foto, deskripsi, benefit, lokasi, jam operasional,
dll). Struktur field jangan diubah supaya semua komponen tetap berfungsi.
Untuk logo/foto, isi field `logo`, `coverImage`, atau `gallery` dengan URL
gambar (atau taruh file gambar di folder `public/` lalu isi dengan path
`/nama-file.jpg`).

## Build untuk production

```bash
npm run build
```

Hasil build ada di folder `dist/` — folder inilah yang di-hosting kalau
deploy manual (bukan lewat Vercel/Netlify otomatis).
