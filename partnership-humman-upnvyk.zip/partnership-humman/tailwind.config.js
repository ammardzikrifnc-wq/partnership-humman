/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        royal: {
          DEFAULT: "#4169E1",
          dark: "#3454BE",
          deep: "#2A429A",
          soft: "#6E8EF0",
        },
        navy: {
          DEFAULT: "#101B3D",
          soft: "#3A4570",
        },
      },
      fontFamily: {
        heading: ["'Plus Jakarta Sans'", "Inter", "sans-serif"],
        body: ["Inter", "'Plus Jakarta Sans'", "sans-serif"],
      },
    },
  },
  plugins: [],
};
