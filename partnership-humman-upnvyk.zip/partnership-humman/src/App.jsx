import { useState } from "react";
import Navbar from "./components/Navbar.jsx";
import HeroSection from "./components/HeroSection.jsx";
import AboutSection from "./components/AboutSection.jsx";
import PartnerGrid from "./components/PartnerGrid.jsx";
import PartnerDetail from "./components/PartnerDetail.jsx";
import Footer from "./components/Footer.jsx";
import { PARTNERS } from "./data/partners.js";

export default function App() {
  const [view, setView] = useState("home");
  const [selectedId, setSelectedId] = useState(null);

  const goHome = () => {
    setView("home");
    setSelectedId(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const scrollToSection = (id) => {
    if (view !== "home") {
      setView("home");
      setSelectedId(null);
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth" });
        else window.scrollTo({ top: 0, behavior: "smooth" });
      }, 60);
      return;
    }
    if (id === "home") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const viewPartner = (id) => {
    setSelectedId(id);
    setView("detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const backToPartners = () => {
    setView("home");
    setSelectedId(null);
    setTimeout(() => {
      const el = document.getElementById("partners");
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }, 60);
  };

  const selectedPartner = PARTNERS.find((p) => p.id === selectedId);

  return (
    <div className="font-body text-navy bg-white">
      <Navbar onNavigate={scrollToSection} />

      {view === "detail" && selectedPartner ? (
        <PartnerDetail partner={selectedPartner} onBack={backToPartners} onHome={goHome} />
      ) : (
        <div id="home">
          <HeroSection onExplore={() => scrollToSection("partners")} />
          <AboutSection />
          <PartnerGrid onView={viewPartner} />
        </div>
      )}

      <Footer onNavigate={scrollToSection} />
    </div>
  );
}
