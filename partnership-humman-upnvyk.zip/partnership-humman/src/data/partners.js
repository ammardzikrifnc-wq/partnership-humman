// ---------------------------------------------------------------------------
// PARTNER DATA
// Ini satu-satunya file yang perlu diedit ketika data partner asli sudah ada.
// Cukup ganti nilai tiap field — struktur (nama field) jangan diubah supaya
// seluruh komponen (PartnerCard, PartnerDetail, dll) tetap berfungsi.
//
// Field:
//   id              - slug unik, dipakai untuk navigasi ke halaman detail
//   name            - nama brand
//   category        - kategori brand (contoh: "Coffee Shop")
//   logo            - path/URL logo (kosongkan "" untuk pakai placeholder)
//   coverImage      - path/URL gambar cover (kosongkan "" untuk placeholder)
//   tagline         - kalimat singkat di halaman detail
//   description     - deskripsi singkat untuk card di grid
//   fullDescription - deskripsi lengkap untuk halaman detail
//   benefits        - array string, benefit yang didapat mahasiswa
//   location        - alamat/lokasi partner
//   operatingHours  - jam operasional
//   status          - status partnership (contoh: "Active Partner")
//   gallery         - array path/URL gambar galeri (kosongkan [] untuk placeholder)
// ---------------------------------------------------------------------------

export const PARTNERS = [
  {
    id: "partner-01",
    name: "Partner 01",
    category: "Coffee Shop",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "08.00 – 21.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-02",
    name: "Partner 02",
    category: "Bakery & Pastry",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "07.00 – 20.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-03",
    name: "Partner 03",
    category: "Fashion & Apparel",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Depok, Sleman",
    operatingHours: "10.00 – 22.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-04",
    name: "Partner 04",
    category: "Print & Merchandise",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "09.00 – 18.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-05",
    name: "Partner 05",
    category: "Fitness & Wellness",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "06.00 – 21.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-06",
    name: "Partner 06",
    category: "Bookstore & Stationery",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "08.00 – 20.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-07",
    name: "Partner 07",
    category: "Photography Studio",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "10.00 – 19.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
  {
    id: "partner-08",
    name: "Partner 08",
    category: "Culinary & Resto",
    logo: "",
    coverImage: "",
    tagline: "Placeholder tagline for this brand partner.",
    description:
      "Placeholder description for partner. Konten ini akan digantikan dengan deskripsi resmi brand ketika data partner sudah tersedia.",
    fullDescription:
      "Placeholder description for partner. Bagian ini menjelaskan profil brand secara lebih lengkap — sejarah singkat, produk unggulan, serta nilai yang ditawarkan kepada mahasiswa Manajemen UPNVYK. Konten final akan menggantikan placeholder ini pada tahap berikutnya.",
    benefits: [
      "Special Student Offer",
      "Exclusive Discount",
      "Special Promotion",
      "Student Benefits",
    ],
    location: "Placeholder Location, Sleman, Yogyakarta",
    operatingHours: "11.00 – 22.00 WIB",
    status: "Active Partner",
    gallery: [],
  },
];

export const NAV_ITEMS = [
  { label: "Home", target: "home" },
  { label: "About Partnership", target: "about" },
  { label: "Our Partners", target: "partners" },
];

export const BENEFITS = [
  {
    key: "students",
    title: "For Students",
    text: "Memberikan akses kepada mahasiswa terhadap berbagai brand dan layanan yang relevan.",
  },
  {
    key: "partners",
    title: "For Partners",
    text: "Membuka peluang kolaborasi dan memperkenalkan brand kepada mahasiswa Manajemen.",
  },
  {
    key: "humman",
    title: "For HUMMAN",
    text: "Membangun hubungan kolaboratif dengan berbagai pihak eksternal.",
  },
];
