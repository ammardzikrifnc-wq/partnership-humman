import { GraduationCap, Handshake, Building2 } from "lucide-react";
import { BENEFITS } from "../data/partners.js";

const ICONS = {
  students: GraduationCap,
  partners: Handshake,
  humman: Building2,
};

export default function AboutSection() {
  return (
    <section id="about" className="px-5 py-24 bg-white scroll-mt-[84px]">
      <div className="max-w-[1080px] mx-auto">
        <div className="max-w-[660px] mx-auto mb-14 text-center">
          <p className="text-[13px] font-bold tracking-[1.6px] text-royal mb-3">
            ABOUT PARTNERSHIP
          </p>
          <h2
            className="font-heading font-extrabold text-navy mb-5 tracking-tight"
            style={{ fontSize: "clamp(1.7rem, 3.4vw, 2.3rem)" }}
          >
            Apa Itu Partnership HUMMAN?
          </h2>
          <p className="text-[15.5px] leading-[1.8] text-navy-soft">
            Partnership HUMMAN merupakan bentuk kolaborasi antara Himpunan
            Mahasiswa Program Studi Manajemen UPN &ldquo;Veteran&rdquo;
            Yogyakarta dengan berbagai brand, bisnis, dan UMKM untuk
            memberikan nilai tambah serta akses terhadap berbagai produk dan
            layanan yang relevan bagi mahasiswa.
          </p>
        </div>

        <div className="grid gap-5" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))" }}>
          {BENEFITS.map((b, i) => {
            const Icon = ICONS[b.key];
            return (
              <div
                key={b.key}
                className="ph-benefit ph-reveal bg-[#F3F6FE] border border-[#E4E9F6] rounded-[18px] p-7"
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className="ph-benefit-icon w-[46px] h-[46px] rounded-[13px] bg-white border border-[#D3DCF5] flex items-center justify-center mb-4.5">
                  <Icon size={21} strokeWidth={1.8} className="text-royal" />
                </div>
                <h3 className="text-[16.5px] font-bold text-navy mb-2">{b.title}</h3>
                <p className="text-sm leading-[1.65] text-navy-soft m-0">{b.text}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
