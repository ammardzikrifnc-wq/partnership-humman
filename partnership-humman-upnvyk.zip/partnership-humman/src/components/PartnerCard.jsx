import { ArrowRight, Tag } from "lucide-react";
import ImagePlaceholder from "./ImagePlaceholder.jsx";

export default function PartnerCard({ partner, onView, index = 0 }) {
  return (
    <div
      className="ph-card ph-reveal bg-white border border-[#E4E9F6] rounded-[18px] p-4 flex flex-col"
      style={{ animationDelay: `${Math.min(index, 8) * 0.05}s` }}
    >
      <div className="overflow-hidden rounded-[13px] mb-4">
        <div className="ph-card-img">
          <ImagePlaceholder
            src={partner.coverImage || partner.logo}
            alt={partner.name}
            label="Partner Logo"
            ratio="aspect-[4/3]"
            rounded="rounded-none"
          />
        </div>
      </div>

      <div className="flex items-center gap-1.5 mb-2">
        <Tag size={12} className="text-royal" />
        <span className="text-[11.5px] font-bold text-royal tracking-wide">
          {partner.category.toUpperCase()}
        </span>
      </div>

      <h3 className="text-[17px] font-bold text-navy mb-2">{partner.name}</h3>

      <p className="text-[13.5px] leading-[1.6] text-navy-soft mb-4.5 flex-grow">
        {partner.description}
      </p>

      <button
        className="ph-link-arrow ph-focus inline-flex items-center gap-1.5 bg-transparent border-none cursor-pointer py-1.5 px-0.5 text-[13.5px] font-bold text-navy font-heading"
        onClick={() => onView(partner.id)}
      >
        View Partner
        <ArrowRight size={14} />
      </button>
    </div>
  );
}
