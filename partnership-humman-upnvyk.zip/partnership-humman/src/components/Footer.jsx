import { NAV_ITEMS } from "../data/partners.js";

export default function Footer({ onNavigate }) {
  return (
    <footer className="bg-navy px-5 pt-14 pb-8">
      <div className="max-w-[1080px] mx-auto flex flex-wrap justify-between gap-8 pb-8 border-b border-white/10">
        <div className="max-w-[340px]">
          <div className="font-heading font-extrabold text-[15.5px] text-white mb-2.5 tracking-wide">
            PARTNERSHIP HUMMAN UPNVYK
          </div>
          <p className="text-[13.5px] leading-[1.7] text-white/60 m-0">
            Himpunan Mahasiswa Program Studi Manajemen
            <br />
            UPN &ldquo;Veteran&rdquo; Yogyakarta
          </p>
        </div>

        <div className="flex gap-10 flex-wrap">
          <div>
            <p className="text-xs font-bold text-white/40 tracking-widest mb-3.5">NAVIGATION</p>
            <div className="flex flex-col gap-2.5">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.target}
                  className="ph-focus bg-transparent border-none cursor-pointer text-left p-0 text-sm text-white/80"
                  onClick={() => onNavigate(item.target)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <p className="text-[12.5px] text-white/40 text-center mt-6 mb-0">
        © 2026 Partnership HUMMAN UPNVYK. All rights reserved.
      </p>
    </footer>
  );
}
