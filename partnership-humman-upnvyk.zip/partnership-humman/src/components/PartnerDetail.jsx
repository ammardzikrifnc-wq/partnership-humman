import { BadgeCheck, ChevronLeft, Clock, MapPin, Sparkles, Tag } from "lucide-react";
import ImagePlaceholder from "./ImagePlaceholder.jsx";

export default function PartnerDetail({ partner, onBack, onHome }) {
  const galleryCount = partner.gallery?.length > 0 ? partner.gallery.length : 4;
  const galleryItems = partner.gallery?.length > 0 ? partner.gallery : Array(4).fill(null);

  return (
    <div className="bg-white">
      <div className="max-w-[1080px] mx-auto px-5 pt-8">
        <div className="flex items-center gap-1.5 text-[13px] text-[#8A90A6] flex-wrap">
          <button className="ph-focus bg-transparent border-none cursor-pointer text-[#8A90A6] text-[13px] p-0.5" onClick={onHome}>
            Home
          </button>
          <span>/</span>
          <button className="ph-focus bg-transparent border-none cursor-pointer text-[#8A90A6] text-[13px] p-0.5" onClick={onBack}>
            Our Partners
          </button>
          <span>/</span>
          <span className="text-navy font-semibold">{partner.name}</span>
        </div>
      </div>

      <section className="ph-detail-hero max-w-[1080px] mx-auto px-5 pt-8 pb-14 grid gap-10 items-start"
        style={{ gridTemplateColumns: "minmax(200px, 340px) 1fr" }}>
        <ImagePlaceholder src={partner.logo} alt={partner.name} label="Partner Logo" ratio="aspect-square" rounded="rounded-[20px]" />

        <div>
          <div className="flex items-center gap-1.5 mb-3">
            <Tag size={13} className="text-royal" />
            <span className="text-[12.5px] font-bold text-royal tracking-wide">
              {partner.category.toUpperCase()}
            </span>
          </div>
          <h1
            className="font-heading font-extrabold text-navy mb-3.5 tracking-tight"
            style={{ fontSize: "clamp(1.9rem, 4vw, 2.6rem)" }}
          >
            {partner.name}
          </h1>
          <p className="text-base leading-[1.7] text-navy-soft mb-6 max-w-[480px]">
            {partner.tagline}
          </p>
          <div className="inline-flex items-center gap-1.5 bg-[#F3F6FE] border border-[#E4E9F6] rounded-full py-1.5 px-4 text-[12.5px] font-bold text-royal-deep">
            <BadgeCheck size={14} />
            {partner.status}
          </div>
        </div>
      </section>

      <section className="max-w-[1080px] mx-auto px-5 pb-16">
        <h2 className="text-xl font-bold text-navy mb-4">About Partner</h2>
        <p className="text-[15.5px] leading-[1.85] text-navy-soft max-w-[760px] m-0">
          {partner.fullDescription}
        </p>
      </section>

      <section className="bg-[#F3F6FE] px-5 py-16">
        <div className="max-w-[1080px] mx-auto">
          <h2 className="text-xl font-bold text-navy mb-5">What Students Get</h2>
          <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
            {partner.benefits.map((b) => (
              <div key={b} className="ph-card bg-white border border-[#E4E9F6] rounded-[15px] p-5 flex items-center gap-3">
                <div className="w-[34px] h-[34px] rounded-[10px] bg-[#F3F6FE] flex items-center justify-center shrink-0">
                  <Sparkles size={15} className="text-royal" />
                </div>
                <span className="text-sm font-semibold text-navy">{b}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-[1080px] mx-auto px-5 py-16">
        <h2 className="text-xl font-bold text-navy mb-5">Partner Information</h2>
        <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
          {[
            { icon: Tag, label: "Category", value: partner.category },
            { icon: MapPin, label: "Location", value: partner.location },
            { icon: Clock, label: "Operating Hours", value: partner.operatingHours },
            { icon: BadgeCheck, label: "Partnership Status", value: partner.status },
          ].map((info) => (
            <div key={info.label} className="border border-[#E4E9F6] rounded-[15px] py-4.5 px-5">
              <div className="flex items-center gap-1.5 mb-2">
                <info.icon size={14} className="text-royal" />
                <span className="text-xs font-bold text-[#8A90A6] tracking-wide">
                  {info.label.toUpperCase()}
                </span>
              </div>
              <p className="text-[14.5px] font-semibold text-navy m-0">{info.value}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-[#F3F6FE] px-5 py-16">
        <div className="max-w-[1080px] mx-auto">
          <h2 className="text-xl font-bold text-navy mb-5">Gallery</h2>
          <div className="grid gap-3.5" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))" }}>
            {galleryItems.map((src, i) => (
              <ImagePlaceholder key={i} src={src} label="Image Coming Soon" ratio="aspect-square" rounded="rounded-2xl" />
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-[1080px] mx-auto px-5 pt-12 pb-16">
        <button
          className="ph-link-arrow ph-focus inline-flex items-center gap-2 bg-[#F3F6FE] border border-[#E4E9F6] rounded-xl py-3 px-5 text-sm font-bold text-navy cursor-pointer font-heading"
          onClick={onBack}
        >
          <ChevronLeft size={16} />
          Back to Partners
        </button>
      </div>
    </div>
  );
}
