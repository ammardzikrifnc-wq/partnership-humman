import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { NAV_ITEMS } from "../data/partners.js";

export default function Navbar({ onNavigate }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 bg-white/90 backdrop-blur-md transition-shadow ${
        scrolled ? "border-b border-[#E4E9F6] shadow-[0_6px_24px_-12px_rgba(16,27,61,0.14)]" : "border-b border-transparent"
      }`}
    >
      <div className="max-w-[1180px] mx-auto px-5 py-3.5 flex items-center justify-between">
        <button
          className="ph-focus flex items-center gap-2.5 bg-transparent border-none cursor-pointer p-0"
          onClick={() => onNavigate("home")}
        >
          <div className="w-[38px] h-[38px] rounded-[11px] bg-gradient-to-br from-royal to-royal-deep flex items-center justify-center shrink-0">
            <span className="text-white font-heading font-extrabold text-[15px]">PH</span>
          </div>
          <div className="text-left leading-[1.15]">
            <div className="font-heading font-extrabold text-[14.5px] tracking-wide text-navy">
              PARTNERSHIP HUMMAN
            </div>
            <div className="text-[11px] font-semibold text-royal tracking-[1.2px]">UPNVYK</div>
          </div>
        </button>

        <nav className="ph-desktop-nav flex gap-8">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.target}
              className="ph-navlink ph-focus bg-transparent border-none cursor-pointer text-[14.5px] font-semibold text-navy py-1.5"
              onClick={() => onNavigate(item.target)}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <button
          id="ph-hamburger"
          className="hidden ph-focus bg-[#F3F6FE] border border-[#E4E9F6] rounded-[10px] w-10 h-10 items-center justify-center cursor-pointer"
          onClick={() => setOpen(!open)}
          aria-label={open ? "Close menu" : "Open menu"}
        >
          {open ? <X size={19} className="text-navy" /> : <Menu size={19} className="text-navy" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-[#E4E9F6] bg-white px-5 pt-2.5 pb-4.5 flex flex-col gap-1">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.target}
              className="ph-focus text-left bg-transparent border-none cursor-pointer py-3 px-1.5 text-[15.5px] font-semibold text-navy border-b border-[#F3F6FE]"
              onClick={() => {
                onNavigate(item.target);
                setOpen(false);
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}
