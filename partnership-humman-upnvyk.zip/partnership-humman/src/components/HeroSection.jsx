import { ArrowRight, Sparkles } from "lucide-react";

export default function HeroSection({ onExplore }) {
  return (
    <section className="relative overflow-hidden px-5 pt-24 pb-28 bg-[radial-gradient(circle_at_18%_20%,#F3F6FE_0%,#FFFFFF_55%)]">
      <div
        aria-hidden="true"
        className="absolute -top-28 -right-24 w-[420px] h-[420px] rounded-[48%_52%_55%_45%/45%_48%_52%_55%] bg-gradient-to-br from-royal/15 to-royal-soft/20"
        style={{ animation: "ph-blob 12s ease-in-out infinite" }}
      />
      <div
        aria-hidden="true"
        className="absolute -bottom-36 -left-20 w-[340px] h-[340px] rounded-[52%_48%_45%_55%/55%_45%_55%_45%] bg-gradient-to-br from-royal-soft/15 to-royal/10"
        style={{ animation: "ph-blob2 14s ease-in-out infinite" }}
      />
      <div
        aria-hidden="true"
        className="absolute top-16 left-[8%] w-[90px] h-[90px] border-2 border-royal/25 rounded-[20px] rotate-[18deg]"
      />

      <div className="max-w-[780px] mx-auto relative text-center">
        <div className="ph-reveal inline-flex items-center gap-1.5 bg-[#F3F6FE] border border-[#E4E9F6] rounded-full py-1.5 px-4 text-[12.5px] font-semibold text-royal-deep mb-6">
          <Sparkles size={13.5} />
          Partnership Directory · Manajemen UPNVYK
        </div>

        <h1
          className="ph-reveal font-heading font-extrabold text-navy leading-[1.08] tracking-tight mb-5"
          style={{ fontSize: "clamp(2.4rem, 5.4vw, 3.6rem)", animationDelay: "0.08s" }}
        >
          Connect. Collaborate. <span className="text-royal">Grow.</span>
        </h1>

        <p
          className="ph-reveal text-[17px] leading-[1.7] text-navy-soft max-w-[560px] mx-auto mb-10"
          style={{ animationDelay: "0.16s" }}
        >
          Kenali berbagai brand dan UMKM yang menjadi partner HUMMAN UPNVYK dan
          temukan berbagai kesempatan menarik untuk mahasiswa Manajemen.
        </p>

        <button
          className="ph-btn-primary ph-focus ph-reveal inline-flex items-center gap-2.5 bg-royal text-white border-none rounded-[13px] py-4 px-7 text-[15px] font-bold cursor-pointer font-heading"
          style={{ animationDelay: "0.24s" }}
          onClick={onExplore}
        >
          Explore Our Partners
          <ArrowRight size={17} />
        </button>
      </div>
    </section>
  );
}
