import { PARTNERS } from "../data/partners.js";
import PartnerCard from "./PartnerCard.jsx";

export default function PartnerGrid({ onView }) {
  return (
    <section id="partners" className="px-5 pt-24 pb-24 bg-[#F3F6FE] scroll-mt-[84px]">
      <div className="max-w-[1180px] mx-auto">
        <div className="max-w-[560px] mx-auto mb-12 text-center">
          <p className="text-[13px] font-bold tracking-[1.6px] text-royal mb-3">
            OUR PARTNERS
          </p>
          <h2
            className="font-heading font-extrabold text-navy mb-3.5 tracking-tight"
            style={{ fontSize: "clamp(1.7rem, 3.4vw, 2.3rem)" }}
          >
            Our Partners
          </h2>
          <p className="text-[15px] leading-[1.7] text-navy-soft m-0">
            Explore brands and businesses collaborating with HUMMAN UPNVYK.
          </p>
        </div>

        <div
          className="grid gap-5"
          style={{ gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))" }}
        >
          {PARTNERS.map((p, i) => (
            <PartnerCard key={p.id} partner={p} onView={onView} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
