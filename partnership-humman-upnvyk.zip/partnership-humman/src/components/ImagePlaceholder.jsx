import { Image as ImageIcon } from "lucide-react";

export default function ImagePlaceholder({
  src,
  alt = "",
  label = "Partner Logo",
  ratio = "aspect-[4/3]",
  rounded = "rounded-2xl",
}) {
  if (src) {
    return (
      <img
        src={src}
        alt={alt || label}
        className={`w-full object-cover ${ratio} ${rounded}`}
      />
    );
  }

  return (
    <div
      className={`w-full ${ratio} ${rounded} border-[1.5px] border-dashed border-royal/30 bg-gradient-to-br from-[#F3F6FE] to-[#EAF0FD] flex flex-col items-center justify-center gap-2`}
    >
      <ImageIcon size={26} strokeWidth={1.6} className="text-royal opacity-75" aria-hidden="true" />
      <span className="text-[12.5px] font-semibold text-royal-deep tracking-wide">{label}</span>
    </div>
  );
}
